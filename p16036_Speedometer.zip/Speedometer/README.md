Speedometer app
