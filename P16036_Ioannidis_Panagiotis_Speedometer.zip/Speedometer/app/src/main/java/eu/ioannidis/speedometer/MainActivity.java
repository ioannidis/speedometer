package eu.ioannidis.speedometer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements LocationListener {

    TextView speedTextView;
    Button enableButton;
    Button disableButton;
    Boolean isEnabled = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        speedTextView = findViewById(R.id.speedTextView);

        enableButton = findViewById(R.id.enableButton);
        enableButton.setBackgroundColor(Color.parseColor("#00796b"));
        enableButton.setTextColor(Color.WHITE);
        enableButton.setOnClickListener((View view) -> {
            isEnabled = true;
            buttonBgColor();
            accessData();
            Toast.makeText(this, "Speed capture is enabled", Toast.LENGTH_SHORT).show();
        });

        disableButton = findViewById(R.id.disableButton);
        disableButton.setBackgroundColor(Color.LTGRAY);
        disableButton.setTextColor(Color.DKGRAY);
        disableButton.setOnClickListener((View view) -> {
            isEnabled = false;
            buttonBgColor();
            speedTextView.setText("---");
            Toast.makeText(this, "Speed capture is disabled", Toast.LENGTH_SHORT).show();
        });


        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
        } else {
            accessData();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 1000) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                accessData();
            else
                finish();
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onLocationChanged(Location location) {
        if (location != null) {
            if (isEnabled) {
                float currentSpeed = location.getSpeed();
                speedTextView.setText(String.valueOf(SpeedConverter.mPerSecToKmPerHr(currentSpeed)));
            }
        } else {
            speedTextView.setText("---");
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }


    @SuppressLint("MissingPermission")
    private void accessData() {
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (locationManager != null && isEnabled) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        }
        Toast.makeText(this, "Waiting for GPS connection", Toast.LENGTH_SHORT).show();
    }

    private void buttonBgColor() {
        if (isEnabled) {
            enableButton.setBackgroundColor(Color.parseColor("#00796b"));
            enableButton.setTextColor(Color.WHITE);
            disableButton.setBackgroundColor(Color.LTGRAY);
            disableButton.setTextColor(Color.DKGRAY);
        } else {
            enableButton.setBackgroundColor(Color.LTGRAY);
            enableButton.setTextColor(Color.DKGRAY);
            disableButton.setBackgroundColor(Color.parseColor("#00796b"));
            disableButton.setTextColor(Color.WHITE);
        }
    }

}
