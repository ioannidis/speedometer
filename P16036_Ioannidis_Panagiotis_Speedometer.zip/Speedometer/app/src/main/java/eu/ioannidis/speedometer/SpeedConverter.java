package eu.ioannidis.speedometer;

public class SpeedConverter {

    public static int mPerSecToKmPerHr(float meters) {
        return (int)(3.6 * meters);
    }
}
